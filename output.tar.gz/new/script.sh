echo "Enter the first variable: "
read var1
echo "Enter the second variable: "
read var2

if [ "$var1" == "$var2" ]; then
        echo "Both variables are same"
        echo "Hence, performing required operation"
        echo "welcome" | tee file{1..3}.txt
        ls
        cat file{1..3}.txt
        echo "10 files with word welcome in it were created"
        cd ..
        pwd
        ls
        tar -cvzf output.tar.gz new
        echo "file compression success!"
        ls
        git clone https://github.com/Nandha3/Fullytest
        ls
        mv output.tar.gz Fullytest
        cd Fullytest
        ls
        echo "activating git"
        git checkout -b master main
        git add .
        git status
        git commit -m "moving to master branch"
        git push -f origin master
        read -p "Username for 'https://github.com':" echo "Nandha3"
else
        echo "only correct"
fi
